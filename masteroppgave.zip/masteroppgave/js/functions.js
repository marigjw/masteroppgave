/**
 * Created by marigjeiloweberg on 24.11.14.
 */

var radbody = false;
/**Timer function*/
var minutes = '';
var totalMinutes = 0;
function startTimer(timeScience) {
    minutes = timeScience;
    setInterval(setTime, 1000);
}
function setTime(){
    ++totalMinutes;
    minutes.innerHTML = pad(parseInt(totalMinutes/60));
}

function pad(val){
    var valString = val + "";
    if(valString.length < 2){
        return "0" + valString + "min";
    }
    else{
        return valString + "min";
    }
}
/** Countdown functions*/
var seconds = '';
var totalSec = 0;
var lastTotalSec = 0;

function startCountDown(secondsLabel, totalsecNew){
    totalSec = totalsecNew;
    lastTotalSec = totalsecNew;
    countOff = false;
    seconds = secondsLabel;
    this.timer = setInterval(setSec, 1000);
}
function setSec(){
    --totalSec;
    seconds.innerHTML = createText(totalSec%60);
}
var countOff = false;

function createText(val){

    var valText = val + "";
    if(valText.length < 2 && countOff == false){
        return "0" + valText + "sek";
    }
    else if( val < 0){

        clearInterval(this.timer);

        return lastTotalSec + "sek";
    }
    else if(valText.length === 2 && countOff == false){
        return valText + "sek";
    }
}
/** Security team*/
var value = '';
var totalValue;
var ok;

function startTest(valueLabel, check){
        document.getElementById('comms_btn').disabled = true;
        document.getElementById('data_btn').disabled = true;

        value = valueLabel;
        totalValue = 0;
        this.values = setInterval(setValue, 100);
        ok = check;



}

function setValue(){
    ++totalValue;
    value.innerHTML = makeValueLabel(parseInt(totalValue));
    if(value.innerHTML == "Feilet!" || value.innerHTML == "OK!"){
      setTimeout(function(){clearProgressbar()}, 20000);
    }


}

function makeValueLabel(val){
    var valString = val + "";
    value.style.width = valString + "%";
    if(val === 100 && ok){
        value.style.backgroundColor = "green";
        clearInterval(this.values);
        return "OK!";
    }
    else if (val === 100 && !ok){
        value.style.backgroundColor = "indianred";
       clearInterval(this.values);
        return"Feilet!";
    }
    else {
        return valString + "%";
    }

}

function clearProgressbar(){
  value.innerHTML = "0%";
  value.style.width = (0 + "%");
  value.style.backgroundColor = "#4286ca";
  document.getElementById('comms_btn').disabled = false;
  document.getElementById('data_btn').disabled = false;

}
var count_pic = 0;
var xmlDoc=loadXMLDoc("test.xml");

function updateOksygenTank(count){
    console.log(document.getElementById("oksygentank").src);

    x = xmlDoc.getElementsByTagName("PICTURE");
    console.log(x[count_pic].getElementsByTagName("URL")[0].innerHTML);
    document.getElementById("oksygentank").src = x[count_pic].getElementsByTagName("URL")[0].innerHTML;
    updatePic();

}

function updatePic () {
    if(count_pic < 7) {
        count_pic++;
    }
    else{
        count_pic = 0;
    }

}


/** read XML file*/
function loadXMLDoc(filename)
{
    if (window.XMLHttpRequest)
    {
        xhttp=new XMLHttpRequest();
    }
    else // code for IE5 and IE6
    {
        xhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.open("GET",'test.xml',false);
    xhttp.send();
    return xhttp.responseXML;
}


/** Science team*/

var count = 0;

function takeTests(){

    var test1 = document.getElementById('test1');
    var test2 = document.getElementById('test2');
    var test3 = document.getElementById('test3');
    var test4 = document.getElementById('test4');

    x=xmlDoc.getElementsByTagName("TEST");


       if(count == 0){
           test1.value = x[count].getElementsByTagName("VALUE")[0].innerHTML;
           count++;

       }
       else if(count == 1){
           test2.value = x[count].getElementsByTagName("VALUE")[0].innerHTML;
           count++;
       }
       else if(count == 2){
           test3.value = x[count].getElementsByTagName("VALUE")[0].innerHTML;
           count++;
       }
       else if(count == 3){
           test4.value = x[count].getElementsByTagName("VALUE")[0].innerHTML;
           count = 0;
       }

}

var orangeNum = 0;
function radiation(elem){
    var value = elem.value;
    x = xmlDoc.getElementsByTagName("RADIATION");

    if(value < parseInt(x[0].getElementsByTagName("VALUE")[0].innerHTML)){
        elem.style.background = "limegreen";
        //elem.value = value;
        orangeNum = 0
    }
    else if (value >= parseInt((x[0].getElementsByTagName("VALUE")[0].innerHTML)) && value < parseInt( x[1].getElementsByTagName("VALUE")[0].innerHTML)){
        elem.style.background="orange";
        if(orangeNum == 2){
            document.getElementById('sound').play();
            elem.style.background = "indianred";
            orangeNum = 0;
        }
        else {
            orangeNum++;
        }
    }
    else if(value >= parseInt( x[1].getElementsByTagName("VALUE")[0].innerHTML)){
        elem.style.background="indianred";
       // elem.value = value;
        document.getElementById('sound').play();
        orangeNum = 0;
    }
}
function radiationBody(elem){
    x = xmlDoc.getElementsByTagName("RADBODY");
    var value = elem.value;

    if(value < parseInt(x[0].getElementsByTagName("VALUE")[0].innerHTML)){
        radbody = false;
        elem.style.background = "limegreen";
    }
    else if (value >= parseInt((x[0].getElementsByTagName("VALUE")[0].innerHTML)) && value < parseInt( x[1].getElementsByTagName("VALUE")[0].innerHTML)){
        radbody = false;
        elem.style.background = "indianred";
        document.getElementById('sound').play();
    }
    else if(value > parseInt( x[1].getElementsByTagName("VALUE")[0].innerHTML) ){
        radbody = true;
        elem.style.background = "indianred";
        document.getElementById('sound').play();
        document.getElementById('clock_btn').disabled = true;
        document.getElementById('average_radiation').disabled = true;
        document.getElementById('body_radiation').disabled = true;
        document.getElementById('sample_btn').disabled = true;

        document.getElementById('task_Science').innerHTML = "SVÆRT FARLIG STÅRLINGSNIVÅ! MELD FRA TIL SIKKERHETSTEAMET. OPPDRAGET MÅ KANSKJE AVBRYTES.";
        document.getElementById('task_Science').style.color = "red";
    console.log(radbody);
    }
}

function radbodyText(){
    console.log(radbody);
    if(radbody == true){
        document.getElementById('secure_task').innerHTML = "SVÆRT FARLIG STÅRLINGSNIVÅ! MELD FRA TIL SIKKERHETSTEAMET. OPPDRAGET MÅ KANSKJE AVBRYTES.";
        document.getElementById('secure_task').style.color = "red";
    }
    else{
        document.getElementById('secure_task').style.color = "blue";
    }
}

/**Astronaut support team*/
function respiration(value){
    var elem = document.getElementById('o2Used');

    if(value < 0.75){
        elem.style.background = "limegreen";
        elem.value = value;
    }
    else{
        elem.style.background = "indianred";
        document.getElementById('sound').play();
        elem.value = value;
    }
}

function heartRate(value){
    var elem = document.getElementById('heart');

    if(value < 90){
        elem.style.background = "limegreen";
        elem.value = value;
    }
    else if(value >= 90 && value < 120){
        elem.style.background = "orange";
        elem.value = value;
    }
    else {
        elem.style.background = "indianred";
        elem.value = value;
        document.getElementById('sound').play();
    }
}
/**Communication*/
var frekvensOmraade = '';
var satName = '';
function chooseSatelitt(sat) {
    if(sat == "sat1" ){
        frekvensOmraade = document.getElementById('satelitt1');
        satName = "Satelitt 1";
    }
    else if(sat == "sat2"){
        frekvensOmraade = document.getElementById('satelitt2');
        satName = "Satelitt 2";
    }
    else if(sat == "sat3"){
        frekvensOmraade = document.getElementById('satelitt3');
        satName = "Satelitt 3";
    }
}

function satelitt(value){
    var frekvens = 0;
    var frekMin = 0;
    var frekMax = 0;

    frekMin = frekvensOmraade.innerHTML.charAt(0) + frekvensOmraade.innerHTML.charAt(1) + frekvensOmraade.innerHTML.charAt(2);
    frekMax = frekvensOmraade.innerHTML.charAt(6) + frekvensOmraade.innerHTML.charAt(7) + frekvensOmraade.innerHTML.charAt(8);
    frekvens = Math.round(((parseFloat(frekMax) + parseFloat(frekMin))/2)*10)/10;


    if(value == frekvens){
        document.getElementById('frekvens').style.background = "limegreen";
        document.getElementById('satLabel').innerHTML = 'Tilkoblet: '  + satName;
        document.getElementById('satLabel').style.color = "black";
    }
    else if(value >= frekMin && value <= frekMax){
        document.getElementById('frekvens').style.background = "orange";
        document.getElementById('satLabel').innerHTML = 'Tilkoblet: ' + satName;
        document.getElementById('satLabel').style.color = "black";
    }
    else{
        document.getElementById('frekvens').style.background = "indianred";
        document.getElementById('satLabel').innerHTML = 'Kan ikke koble til';
        document.getElementById('satLabel').style.color = "red";
        document.getElementById('sound').play();
    }
}
